# WebScrapingNodeJS
web scraping script for scraping urls from any website 

Getting Started
 
```sh
npm i
node index.js 
```
File .json will be generated in the same folder.
